<?php
define("CONTROLLER_DEFECTO", "Employees");
define("DEFECT_ACTION", "index");
?>